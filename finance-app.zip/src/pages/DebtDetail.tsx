import { useParams } from 'react-router-dom'
import { useAppStore } from '../store/useAppStore'
import { useState } from 'react'

export default function DebtDetail(){
  const { id } = useParams()
  const debtId = Number(id)
  const { debts, debtPayments, addDebtPayment } = useAppStore()
  const d = debts.find((x:any)=>x.id===debtId)
  const [amt,setAmt]=useState('')
  if(!d) return null
  const paid = debtPayments.filter((p:any)=>p.debt_id===debtId).reduce((s:any,p:any)=>s+p.amount,0)
  const total = d.principal * (1 + (d.interest_rate||0)/100)
  const remaining = Math.max(0, total - paid)

  const log = async ()=>{
    await addDebtPayment({debt_id:debtId, amount: parseFloat(amt), date: new Date().toISOString().slice(0,10), note:''})
    setAmt('')
  }

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-bold">{d.person_name}</h1>
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900">
        <div className="flex justify-between"><span>Principal</span><span>${d.principal.toFixed(2)}</span></div>
        <div className="flex justify-between"><span>Interest</span><span>{d.interest_rate||0}%</span></div>
        <div className="flex justify-between font-semibold"><span>Total</span><span>${total.toFixed(2)}</span></div>
        <div className="flex justify-between text-income"><span>Paid</span><span>${paid.toFixed(2)}</span></div>
        <div className="flex justify-between text-expense"><span>Remaining</span><span>${remaining.toFixed(2)}</span></div>
      </div>
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900">
        <div className="font-semibold mb-2">Log Payment</div>
        <div className="flex gap-2"><input value={amt} onChange={e=>setAmt(e.target.value)} inputMode="decimal" placeholder="Amount" className="flex-1 p-3 rounded-xl bg-slate-100 dark:bg-slate-800"/><button onClick={log} className="px-4 rounded-xl bg-primary text-white">Add</button></div>
      </div>
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900">
        <div className="font-semibold mb-2">History</div>
        {debtPayments.filter((p:any)=>p.debt_id===debtId).map((p:any)=><div key={p.id} className="flex justify-between py-1 text-sm"><span>{p.date}</span><span>${p.amount.toFixed(2)}</span></div>)}
      </div>
    </div>
  )
}
