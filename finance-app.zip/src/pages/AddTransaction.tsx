import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAppStore } from '../store/useAppStore'

export default function AddTransaction(){
  const nav = useNavigate()
  const { categories, accounts, addTransaction } = useAppStore()
  const [type,setType]=useState<'income'|'expense'>('expense')
  const [amount,setAmount]=useState('')
  const [category_id,setCat]=useState<number>(categories.find((c:any)=>c.type==='expense')?.id||1)
  const [account_id,setAcc]=useState<number>(accounts[0]?.id||1)
  const [date,setDate]=useState(new Date().toISOString().slice(0,10))
  const [desc,setDesc]=useState('')
  const [method,setMethod]=useState('Cash')
  const [is_recurring,setRec]=useState(false)
  const [rule,setRule]=useState('monthly')

  const save = async ()=>{
    await addTransaction({ account_id, category_id, type, amount: parseFloat(amount), date, description: desc, payment_method: method, is_recurring: is_recurring?1:0, recurrence_rule: is_recurring?rule:null })
    nav('/transactions')
  }

  const cats = categories.filter((c:any)=>c.type===type)

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-bold">Add Transaction</h1>
      <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
        {['expense','income'].map(t=><button key={t} onClick={()=>{setType(t as any); setCat(cats[0]?.id)}} className={`py-2 rounded-xl capitalize ${type===t?'bg-white dark:bg-slate-900 shadow':''}`}>{t}</button>)}
      </div>
      <input inputMode="decimal" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="0.00" className="w-full text-4xl font-bold p-4 rounded-2xl bg-white dark:bg-slate-900 text-center" />
      <div className="grid grid-cols-4 gap-2">{cats.map((c:any)=><button key={c.id} onClick={()=>setCat(c.id)} className={`p-3 rounded-xl text-sm ${category_id===c.id?'bg-primary text-white':'bg-white dark:bg-slate-900'}`}>{c.name}</button>)}</div>
      <select value={account_id} onChange={e=>setAcc(+e.target.value)} className="w-full p-3 rounded-xl bg-white dark:bg-slate-900">{accounts.map((a:any)=><option key={a.id} value={a.id}>{a.name}</option>)}</select>
      <input type="date" value={date} onChange={e=>setDate(e.target.value)} className="w-full p-3 rounded-xl bg-white dark:bg-slate-900" />
      <input value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Description" className="w-full p-3 rounded-xl bg-white dark:bg-slate-900" />
      <select value={method} onChange={e=>setMethod(e.target.value)} className="w-full p-3 rounded-xl bg-white dark:bg-slate-900">{['Cash','Card','Bank Transfer','UPI','Other'].map(m=><option key={m}>{m}</option>)}</select>
      <label className="flex items-center gap-2"><input type="checkbox" checked={is_recurring} onChange={e=>setRec(e.target.checked)}/> Recurring</label>
      {is_recurring && <select value={rule} onChange={e=>setRule(e.target.value)} className="w-full p-3 rounded-xl bg-white dark:bg-slate-900">{['daily','weekly','monthly','yearly'].map(r=><option key={r}>{r}</option>)}</select>}
      <button onClick={save} disabled={!amount} className="w-full py-3 rounded-2xl bg-primary text-white font-semibold disabled:opacity-50">Save</button>
    </div>
  )
}
