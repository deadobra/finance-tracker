import { useAppStore } from '../store/useAppStore'
import { useState } from 'react'

export default function Accounts(){
  const { accounts, addAccount } = useAppStore()
  const [show,setShow]=useState(false)
  const [name,setName]=useState(''); const [type,setType]=useState('bank'); const [balance,setBal]=useState('0')

  const save = async ()=>{ await addAccount({name,type,balance:parseFloat(balance),color:'#6366f1'}); setShow(false); setName(''); setBal('0') }

  const net = accounts.reduce((s:any,a:any)=>s+(a.balance||0),0)

  return (
    <div className="p-4 space-y-4">
      <div className="p-4 rounded-2xl bg-slate-900 text-white"><div className="text-xs opacity-80">Net Worth</div><div className="text-2xl font-bold">${net.toFixed(2)}</div></div>
      <div className="flex justify-between items-center"><h2 className="font-semibold">Accounts</h2><button onClick={()=>setShow(true)} className="px-3 py-1.5 rounded-xl bg-primary text-white text-sm">+ Add</button></div>
      {accounts.map((a:any)=><div key={a.id} className="p-4 rounded-2xl bg-white dark:bg-slate-900 flex justify-between"><div><div className="font-medium">{a.name}</div><div className="text-xs text-slate-500 capitalize">{a.type}</div></div><div className="font-semibold">${(a.balance||0).toFixed(2)}</div></div>)}
      {show && <div className="fixed inset-0 bg-black/50 grid place-items-center p-4"><div className="bg-white dark:bg-slate-900 p-4 rounded-2xl w-full max-w-sm space-y-3"><h3 className="font-bold">New Account</h3><input value={name} onChange={e=>setName(e.target.value)} placeholder="Name" className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800"/><select value={type} onChange={e=>setType(e.target.value)} className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800"><option>cash</option><option>bank</option><option>credit</option><option>savings</option></select><input value={balance} onChange={e=>setBal(e.target.value)} inputMode="decimal" placeholder="Starting balance" className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800"/><div className="flex gap-2"><button onClick={()=>setShow(false)} className="flex-1 py-2 rounded-xl bg-slate-200 dark:bg-slate-800">Cancel</button><button onClick={save} className="flex-1 py-2 rounded-xl bg-primary text-white">Save</button></div></div></div>}
    </div>
  )
}
