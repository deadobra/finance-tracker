import { useAppStore } from '../store/useAppStore'
import { useState } from 'react'
import { Filesystem, Directory } from '@capacitor/filesystem'
import { Capacitor } from '@capacitor/core'
import { Preferences } from '@capacitor/preferences'

export default function Settings(){
  const { user, updateUser, backup, restore, theme } = useAppStore()
  const [pin,setPin]=useState('')

  const exportData = async ()=>{
    const json = await backup()
    if(Capacitor.getPlatform()!=='web'){
      await Filesystem.writeFile({ path:'fintrack-backup.json', data: json, directory: Directory.Documents })
      alert('Saved to Documents/fintrack-backup.json')
    } else {
      const blob = new Blob([json],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='fintrack-backup.json'; a.click()
    }
  }
  const importData = async (e:any)=>{
    const file = e.target.files[0]; const text = await file.text(); await restore(text); alert('Restored')
  }
  const setPinLock = async ()=>{
    await Preferences.set({key:'pin', value: btoa(pin)}); alert('PIN set')
  }
  const toggleTheme = async ()=>{
    const next = theme==='dark'?'light':'dark'; await updateUser({...user, theme: next})
  }

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-bold">Settings</h1>
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 space-y-3">
        <div><div className="text-xs text-slate-500">Name</div><input defaultValue={user?.name} onBlur={e=>updateUser({...user,name:e.target.value})} className="w-full p-2 rounded bg-slate-100 dark:bg-slate-800"/></div>
        <div><div className="text-xs text-slate-500">Currency</div><select defaultValue={user?.currency} onChange={e=>updateUser({...user,currency:e.target.value})} className="w-full p-2 rounded bg-slate-100 dark:bg-slate-800"><option>USD</option><option>EUR</option><option>INR</option><option>PKR</option></select></div>
      </div>
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 space-y-3">
        <button onClick={toggleTheme} className="w-full py-2 rounded-xl bg-slate-100 dark:bg-slate-800">Toggle {theme==='dark'?'Light':'Dark'} Mode</button>
        <div className="flex gap-2"><input value={pin} onChange={e=>setPin(e.target.value)} placeholder="4-digit PIN" className="flex-1 p-2 rounded bg-slate-100 dark:bg-slate-800"/><button onClick={setPinLock} className="px-3 rounded bg-primary text-white">Set PIN</button></div>
      </div>
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 space-y-3">
        <button onClick={exportData} className="w-full py-2 rounded-xl bg-slate-100 dark:bg-slate-800">Export Backup (JSON)</button>
        <label className="block w-full py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-center cursor-pointer">Import Backup<input type="file" accept="application/json" className="hidden" onChange={importData}/></label>
        <button onClick={()=>{ if(confirm('Clear all data?')){ localStorage.clear(); location.reload() } }} className="w-full py-2 rounded-xl bg-expense text-white">Clear All Data</button>
      </div>
      <div className="text-center text-xs text-slate-500 pt-4">Finance Tracker v1.0 • Offline-first</div>
    </div>
  )
}
