import { useState } from 'react'
import { useAppStore } from '../store/useAppStore'
import { motion } from 'framer-motion'

export default function Onboarding(){
  const [step,setStep]=useState(1)
  const [name,setName]=useState('')
  const [currency,setCurrency]=useState('USD')
  const [accName,setAccName]=useState('Cash Wallet')
  const createUser = useAppStore(s=>s.createUser)
  const addAccount = useAppStore(s=>s.addAccount)

  const finish = async ()=>{
    await createUser(name,currency)
    await addAccount({name:accName,type:'cash',balance:0,color:'#6366f1'})
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-b from-indigo-600 to-violet-700 text-white">
      <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="w-full max-w-sm bg-white/10 backdrop-blur rounded-3xl p-6 shadow-xl">
        {step===1 && (
          <div className="text-center space-y-4">
            <h1 className="text-3xl font-bold">Finance Tracker</h1>
            <p className="text-white/80">Offline-first money & debt manager</p>
            <button onClick={()=>setStep(2)} className="w-full py-3 rounded-2xl bg-white text-indigo-700 font-semibold">Get Started</button>
          </div>
        )}
        {step===2 && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Your profile</h2>
            <input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" className="w-full p-3 rounded-xl text-slate-900" />
            <select value={currency} onChange={e=>setCurrency(e.target.value)} className="w-full p-3 rounded-xl text-slate-900">
              <option>USD</option><option>EUR</option><option>GBP</option><option>INR</option><option>PKR</option><option>BDT</option>
            </select>
            <button disabled={!name} onClick={()=>setStep(3)} className="w-full py-3 rounded-2xl bg-white text-indigo-700 font-semibold disabled:opacity-50">Continue</button>
          </div>
        )}
        {step===3 && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">First account</h2>
            <input value={accName} onChange={e=>setAccName(e.target.value)} className="w-full p-3 rounded-xl text-slate-900" />
            <button onClick={finish} className="w-full py-3 rounded-2xl bg-white text-indigo-700 font-semibold">Finish</button>
          </div>
        )}
      </motion.div>
    </div>
  )
}
