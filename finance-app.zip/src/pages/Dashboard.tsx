import { useAppStore } from '../store/useAppStore'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts'
import { format } from 'date-fns'

export default function Dashboard(){
  const { accounts, transactions, categories, budgets, debts } = useAppStore()
  const total = accounts.reduce((s:any,a:any)=>s+(a.balance||0),0)
  const now = new Date(); const m = now.getMonth()+1; const y = now.getFullYear()
  const monthTx = transactions.filter((t:any)=> new Date(t.date).getMonth()+1===m)
  const income = monthTx.filter((t:any)=>t.type==='income').reduce((s:any,t:any)=>s+t.amount,0)
  const expense = monthTx.filter((t:any)=>t.type==='expense').reduce((s:any,t:any)=>s+t.amount,0)

  const last6 = [...Array(6)].map((_,i)=>{ const d=new Date(y,m-1-i,1); return { label: format(d,'MMM'), income:0, expense:0 } }).reverse()
  transactions.forEach((t:any)=>{ const d=new Date(t.date); const idx=last6.findIndex(x=>x.label===format(d,'MMM')); if(idx>=0) last6[idx][t.type]+=t.amount })

  const expByCat = categories.filter((c:any)=>c.type==='expense').map((c:any)=>({name:c.name, value: monthTx.filter((t:any)=>t.category_id===c.id).reduce((s:any,t:any)=>s+t.amount,0), color:c.color })).filter(x=>x.value>0)

  const daily = [...Array(30)].map((_,i)=>{ const d=new Date(); d.setDate(d.getDate()-29+i); const sum=transactions.filter((t:any)=>t.type==='expense' && new Date(t.date).toDateString()===d.toDateString()).reduce((s:any,t:any)=>s+t.amount,0); return {d:format(d,'dd'), v:sum} })

  const upcomingDebts = debts.filter((d:any)=>d.status!=='paid' && d.due_date).sort((a:any,b:any)=>+new Date(a.due_date)-+new Date(b.due_date)).slice(0,3)

  return (
    <div className="p-4 space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="p-4 rounded-2xl bg-indigo-600 text-white"><div className="text-xs opacity-80">Total Balance</div><div className="text-2xl font-bold">${total.toFixed(2)}</div></div>
        <div className="p-4 rounded-2xl bg-slate-900 text-white"><div className="text-xs opacity-80">This Month</div><div className="text-sm">+${income.toFixed(0)} / -${expense.toFixed(0)}</div><div className={`text-lg font-semibold ${income-expense>=0?'text-income':'text-expense'}`}>Net ${(income-expense).toFixed(0)}</div></div>
      </div>

      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 shadow-sm">
        <div className="font-semibold mb-2">Income vs Expenses</div>
        <div className="h-40"><ResponsiveContainer><BarChart data={last6}><XAxis dataKey="label"/><YAxis hide/><Tooltip/><Bar dataKey="income" fill="#22c55e" radius={6}/><Bar dataKey="expense" fill="#ef4444" radius={6}/></BarChart></ResponsiveContainer></div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 shadow-sm">
          <div className="font-semibold mb-2">Spending</div>
          <div className="h-32"><ResponsiveContainer><PieChart><Pie data={expByCat} dataKey="value" innerRadius={30} outerRadius={50}>{expByCat.map((e:any,i:number)=><Cell key={i} fill={e.color}/>)}</Pie></PieChart></ResponsiveContainer></div>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 shadow-sm">
          <div className="font-semibold mb-2">Daily (30d)</div>
          <div className="h-32"><ResponsiveContainer><LineChart data={daily}><Line type="monotone" dataKey="v" stroke="#6366f1" strokeWidth={2} dot={false}/></LineChart></ResponsiveContainer></div>
        </div>
      </div>

      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 shadow-sm">
        <div className="font-semibold mb-2">Budget alerts</div>
        {budgets.filter((b:any)=>b.month===m&&b.year===y).map((b:any)=>{
          const spent = monthTx.filter((t:any)=>t.category_id===b.category_id).reduce((s:any,t:any)=>s+t.amount,0)
          const pct = Math.min(100, (spent/b.limit_amount)*100)
          const color = pct>90?'bg-expense':pct>60?'bg-amber-500':'bg-income'
          const cat = categories.find((c:any)=>c.id===b.category_id)
          return <div key={b.id} className="mb-2"><div className="flex justify-between text-sm"><span>{cat?.name}</span><span>${spent.toFixed(0)}/${b.limit_amount}</span></div><div className="h-2 bg-slate-200 dark:bg-slate-800 rounded"><div className={`h-2 rounded ${color}`} style={{width:`${pct}%`}}/></div></div>
        })}
        {budgets.length===0 && <div className="text-sm text-slate-500">No budgets set</div>}
      </div>

      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 shadow-sm">
        <div className="font-semibold mb-2">Upcoming debts</div>
        {upcomingDebts.map((d:any)=><div key={d.id} className="flex justify-between py-1 text-sm"><span>{d.person_name}</span><span className={new Date(d.due_date)<new Date()?'text-expense':''}>{format(new Date(d.due_date),'MMM dd')}</span></div>)}
        {upcomingDebts.length===0 && <div className="text-sm text-slate-500">All clear</div>}
      </div>
    </div>
  )
}
