import { useState } from 'react'
import { useAppStore } from '../store/useAppStore'
import { Link } from 'react-router-dom'

export default function Debts(){
  const { debts, debtPayments, addDebt } = useAppStore()
  const [tab,setTab]=useState<'i_owe'|'owed_to_me'>('i_owe')
  const [show,setShow]=useState(false)
  const [form,setForm]=useState<any>({person_name:'',direction:'i_owe',principal:'',due_date:'',interest_rate:0})

  const list = debts.filter((d:any)=>d.direction===tab)
  const totalOwe = debts.filter((d:any)=>d.direction==='i_owe').reduce((s:any,d:any)=>s+d.principal,0)
  const totalOwed = debts.filter((d:any)=>d.direction==='owed_to_me').reduce((s:any,d:any)=>s+d.principal,0)

  const save = async ()=>{
    await addDebt({...form, principal: parseFloat(form.principal), interest_type:'simple', start_date: new Date().toISOString().slice(0,10), status:'active'})
    setShow(false); setForm({person_name:'',direction:tab,principal:'',due_date:'',interest_rate:0})
  }

  return (
    <div className="p-4 space-y-4">
      <div className="grid grid-cols-3 gap-2">
        <div className="p-3 rounded-xl bg-owe text-white"><div className="text-xs">I Owe</div><div className="font-bold">${totalOwe.toFixed(0)}</div></div>
        <div className="p-3 rounded-xl bg-owed text-white"><div className="text-xs">Owed to me</div><div className="font-bold">${totalOwed.toFixed(0)}</div></div>
        <div className="p-3 rounded-xl bg-slate-900 text-white"><div className="text-xs">Net</div><div className="font-bold">${(totalOwed-totalOwe).toFixed(0)}</div></div>
      </div>

      <div className="flex gap-2">
        {(['i_owe','owed_to_me'] as const).map(t=><button key={t} onClick={()=>setTab(t)} className={`px-4 py-2 rounded-xl ${tab===t?'bg-primary text-white':'bg-white dark:bg-slate-900'}`}>{t==='i_owe'?'I OWE':'OWED TO ME'}</button>)}
        <button onClick={()=>setShow(true)} className="ml-auto px-4 py-2 rounded-xl bg-primary text-white">+ Add</button>
      </div>

      {list.map((d:any)=>{
        const paid = debtPayments.filter((p:any)=>p.debt_id===d.id).reduce((s:any,p:any)=>s+p.amount,0)
        const pct = Math.min(100, (paid/d.principal)*100)
        const overdue = d.due_date && new Date(d.due_date) < new Date() && d.status!=='paid'
        return <Link to={`/debts/${d.id}`} key={d.id} className="block p-4 rounded-2xl bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex justify-between"><div className="font-semibold">{d.person_name}</div><div className={`text-xs px-2 py-0.5 rounded ${overdue?'bg-expense text-white':'bg-slate-200 dark:bg-slate-800'}`}>{d.status}</div></div>
          <div className="text-sm text-slate-500">${paid.toFixed(0)} / ${d.principal.toFixed(0)}</div>
          <div className="h-2 bg-slate-200 dark:bg-slate-800 rounded mt-2"><div className="h-2 bg-primary rounded" style={{width:`${pct}%`}}/></div>
          {d.due_date && <div className="text-xs mt-1">Due {d.due_date}</div>}
        </Link>
      })}

      {show && (
        <div className="fixed inset-0 bg-black/50 grid place-items-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl p-4 space-y-3">
            <h3 className="font-bold">Add Debt</h3>
            <select value={form.direction} onChange={e=>setForm({...form,direction:e.target.value})} className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800"><option value="i_owe">I OWE</option><option value="owed_to_me">OWED TO ME</option></select>
            <input placeholder="Person name" value={form.person_name} onChange={e=>setForm({...form,person_name:e.target.value})} className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800"/>
            <input placeholder="Amount" inputMode="decimal" value={form.principal} onChange={e=>setForm({...form,principal:e.target.value})} className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800"/>
            <input type="date" value={form.due_date} onChange={e=>setForm({...form,due_date:e.target.value})} className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800"/>
            <div className="flex gap-2"><button onClick={()=>setShow(false)} className="flex-1 py-2 rounded-xl bg-slate-200 dark:bg-slate-800">Cancel</button><button onClick={save} className="flex-1 py-2 rounded-xl bg-primary text-white">Save</button></div>
          </div>
        </div>
      )}
    </div>
  )
}
