import { Link } from 'react-router-dom'
import { useAppStore } from '../store/useAppStore'
import { Plus } from 'lucide-react'
import { format } from 'date-fns'

export default function Transactions(){
  const { transactions, categories, accounts } = useAppStore()
  const grouped = transactions.sort((a:any,b:any)=>+new Date(b.date)-+new Date(a.date)).reduce((acc:any,t:any)=>{ const k=format(new Date(t.date),'yyyy-MM-dd'); (acc[k]=acc[k]||[]).push(t); return acc },{})

  return (
    <div className="p-4 pb-24">
      <div className="flex items-center justify-between mb-3"><h1 className="text-xl font-bold">Transactions</h1><Link to="/transactions/new" className="p-2 rounded-full bg-primary text-white"><Plus/></Link></div>
      {Object.entries(grouped).map(([date,items]:any)=>(
        <div key={date} className="mb-4">
          <div className="text-xs text-slate-500 mb-1">{format(new Date(date),'EEE, MMM d')}</div>
          <div className="space-y-2">
            {items.map((t:any)=>{
              const cat = categories.find((c:any)=>c.id===t.category_id); const acc = accounts.find((a:any)=>a.id===t.account_id)
              return <div key={t.id} className="p-3 rounded-xl bg-white dark:bg-slate-900 flex items-center justify-between shadow-sm">
                <div><div className="font-medium">{t.description || cat?.name}</div><div className="text-xs text-slate-500">{cat?.name} • {acc?.name}</div></div>
                <div className={`font-semibold ${t.type==='income'?'text-income':'text-expense'}`}>{t.type==='income'?'+':'-'}${t.amount.toFixed(2)}</div>
              </div>
            })}
          </div>
        </div>
      ))}
      {transactions.length===0 && <div className="text-center text-slate-500 mt-20">No transactions yet</div>}
    </div>
  )
}
