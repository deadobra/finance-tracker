import { NavLink } from 'react-router-dom'
import { LayoutDashboard, Receipt, Scale, Wallet, Settings } from 'lucide-react'

const tabs = [
  {to:'/', label:'Dashboard', icon: LayoutDashboard},
  {to:'/transactions', label:'Txns', icon: Receipt},
  {to:'/debts', label:'Debts', icon: Scale},
  {to:'/accounts', label:'Accounts', icon: Wallet},
  {to:'/settings', label:'Settings', icon: Settings},
]

export default function BottomNav(){
  return (
    <nav className="fixed bottom-0 inset-x-0 bg-white/90 dark:bg-slate-900/90 backdrop-blur border-t border-slate-200 dark:border-slate-800">
      <div className="max-w-[430px] mx-auto grid grid-cols-5">
        {tabs.map(t=>(
          <NavLink key={t.to} to={t.to} className={({isActive})=>`flex flex-col items-center py-2.5 text-xs ${isActive?'text-primary':'text-slate-500'}`}>
            <t.icon size={22} />
            <span className="mt-0.5">{t.label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  )
}
