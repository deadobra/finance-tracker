import { Capacitor } from '@capacitor/core'
import { getDB } from './init'

const isNative = Capacitor.getPlatform() !== 'web'

type Store = any
function getStore(): Store {
  return JSON.parse(localStorage.getItem('ft_db') || '{}')
}
function setStore(s: Store) { localStorage.setItem('ft_db', JSON.stringify(s)) }
function nextId(arr:any[]){ return arr.length ? Math.max(...arr.map(x=>x.id))+1 : 1 }

export const db = {
  async getUser() {
    if (isNative) {
      const db = await getDB(); const r = await db.query('SELECT * FROM users LIMIT 1'); return r.values?.[0] || null
    } else { return getStore().users?.[0] || null }
  },
  async createUser(name:string,currency:string) {
    if (isNative) { const db = await getDB(); await db.run('INSERT INTO users (name,currency) VALUES (?,?)',[name,currency]) }
    else { const s=getStore(); s.users=[{id:1,name,currency,theme:'light',created_at:new Date().toISOString()}]; setStore(s) }
  },
  async updateUser(patch:any) {
    if (isNative) { const db=await getDB(); await db.run('UPDATE users SET name=?,currency=?,theme=? WHERE id=1',[patch.name,patch.currency,patch.theme]) }
    else { const s=getStore(); s.users[0]={...s.users[0],...patch}; setStore(s) }
  },
  async list(table:string) {
    if (isNative) { const db=await getDB(); const r=await db.query(`SELECT * FROM ${table} ORDER BY id DESC`); return r.values||[] }
    else { return getStore()[table]||[] }
  },
  async insert(table:string, obj:any) {
    if (isNative) {
      const db=await getDB(); const keys=Object.keys(obj); const vals=keys.map(k=>obj[k]);
      const placeholders=keys.map(()=>'?').join(','); await db.run(`INSERT INTO ${table} (${keys.join(',')}) VALUES (${placeholders})`, vals)
    } else { const s=getStore(); obj.id=nextId(s[table]); obj.created_at=new Date().toISOString(); s[table].push(obj); setStore(s); return obj }
  },
  async update(table:string,id:number,patch:any) {
    if (isNative) { const db=await getDB(); const keys=Object.keys(patch); const vals=keys.map(k=>patch[k]); await db.run(`UPDATE ${table} SET ${keys.map(k=>k+'=?').join(',')} WHERE id=?`, [...vals,id]) }
    else { const s=getStore(); const i=s[table].findIndex((x:any)=>x.id===id); s[table][i]={...s[table][i],...patch}; setStore(s) }
  },
  async remove(table:string,id:number) {
    if (isNative) { const db=await getDB(); await db.run(`DELETE FROM ${table} WHERE id=?`,[id]) }
    else { const s=getStore(); s[table]=s[table].filter((x:any)=>x.id!==id); setStore(s) }
  },
  async run(sql:string, params:any[]){ if(isNative){ const db=await getDB(); return db.run(sql,params) } },
  async query(sql:string, params:any[]){ if(isNative){ const db=await getDB(); const r=await db.query(sql,params); return r.values||[] } return [] }
}
