import { Capacitor } from '@capacitor/core'
import { CapacitorSQLite, SQLiteConnection, SQLiteDBConnection } from '@capacitor-community/sqlite'

let db: SQLiteDBConnection | null = null
const DB_NAME = 'finance'

const TABLES = [
`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  email TEXT,
  currency TEXT DEFAULT 'USD',
  theme TEXT DEFAULT 'light',
  created_at TEXT DEFAULT (datetime('now'))
);`,
`CREATE TABLE IF NOT EXISTS accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  type TEXT,
  balance REAL DEFAULT 0,
  color TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);`,
`CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  color TEXT,
  icon TEXT
);`,
`CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER,
  category_id INTEGER,
  type TEXT NOT NULL,
  amount REAL NOT NULL,
  date TEXT NOT NULL,
  description TEXT,
  payment_method TEXT,
  is_recurring INTEGER DEFAULT 0,
  recurrence_rule TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (account_id) REFERENCES accounts(id),
  FOREIGN KEY (category_id) REFERENCES categories(id)
);`,
`CREATE TABLE IF NOT EXISTS budgets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER,
  month INTEGER,
  year INTEGER,
  limit_amount REAL,
  FOREIGN KEY (category_id) REFERENCES categories(id)
);`,
`CREATE TABLE IF NOT EXISTS debts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  person_name TEXT NOT NULL,
  contact TEXT,
  direction TEXT NOT NULL,
  principal REAL NOT NULL,
  interest_rate REAL DEFAULT 0,
  interest_type TEXT DEFAULT 'simple',
  start_date TEXT,
  due_date TEXT,
  status TEXT DEFAULT 'active',
  description TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);`,
`CREATE TABLE IF NOT EXISTS debt_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  debt_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  date TEXT NOT NULL,
  note TEXT,
  FOREIGN KEY (debt_id) REFERENCES debts(id)
);`
]

const seedCategories = [
  ['Salary','income','#22c55e','Briefcase'],
  ['Freelance','income','#16a34a','Laptop'],
  ['Business','income','#0d9488','Store'],
  ['Investment','income','#059669','TrendingUp'],
  ['Gift','income','#84cc16','Gift'],
  ['Other','income','#22c55e','Plus'],
  ['Food','expense','#ef4444','Utensils'],
  ['Rent','expense','#dc2626','Home'],
  ['Transport','expense','#f97316','Car'],
  ['Shopping','expense','#ec4899','ShoppingBag'],
  ['Health','expense','#e11d48','Heart'],
  ['Entertainment','expense','#8b5cf6','Film'],
  ['Utilities','expense','#f59e0b','Zap'],
  ['Education','expense','#3b82f6','GraduationCap'],
  ['Personal Care','expense','#14b8a6','Smile'],
  ['Other','expense','#ef4444','Plus'],
]

const isNative = Capacitor.getPlatform() !== 'web'

export async function getDB(): Promise<SQLiteDBConnection> {
  if (db) return db
  const sqlite = new SQLiteConnection(CapacitorSQLite)
  const ret = await sqlite.checkConnectionsConsistency()
  const isConn = (await sqlite.isConnection(DB_NAME, false)).result
  if (isConn) {
    db = await sqlite.retrieveConnection(DB_NAME, false)
  } else {
    db = await sqlite.createConnection(DB_NAME, false, 'no-encryption', 1, false)
  }
  await db.open()
  return db
}

export async function initDB() {
  if (isNative) {
    const conn = await getDB()
    for (const sql of TABLES) await conn.execute(sql)
    const res = await conn.query('SELECT COUNT(*) as c FROM categories')
    if (res.values?.[0].c === 0) {
      for (const [name,type,color,icon] of seedCategories) {
        await conn.run('INSERT INTO categories (name,type,color,icon) VALUES (?,?,?,?)', [name,type,color,icon])
      }
    }
  } else {
    // web fallback using localStorage
    const store = JSON.parse(localStorage.getItem('ft_db') || '{}')
    if (!store.categories) {
      store.users = []
      store.accounts = []
      store.categories = seedCategories.map((c,i)=>({id:i+1,name:c[0],type:c[1],color:c[2],icon:c[3]}))
      store.transactions = []
      store.budgets = []
      store.debts = []
      store.debt_payments = []
      localStorage.setItem('ft_db', JSON.stringify(store))
    }
  }
}

export async function query(sql: string, params: any[] = []) {
  if (isNative) {
    const conn = await getDB()
    const res = await conn.query(sql, params)
    return res.values || []
  } else {
    // very small SQL-like parser for web fallback - only used by our wrappers
    const store = JSON.parse(localStorage.getItem('ft_db') || '{}')
    // fallback is handled in sqlite.ts wrappers, not here
    return []
  }
}
