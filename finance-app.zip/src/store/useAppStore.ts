import { create } from 'zustand'
import { db } from '../db/sqlite'

export const useAppStore = create<any>((set,get)=>({
  user: null,
  accounts: [],
  categories: [],
  transactions: [],
  budgets: [],
  debts: [],
  debtPayments: [],
  theme: 'light',

  async loadAll() {
    const user = await db.getUser()
    const [accounts,categories,transactions,budgets,debts,debtPayments] = await Promise.all([
      db.list('accounts'), db.list('categories'), db.list('transactions'),
      db.list('budgets'), db.list('debts'), db.list('debt_payments')
    ])
    set({ user, accounts, categories, transactions, budgets, debts, debtPayments, theme: user?.theme || 'light' })
  },
  async createUser(name:string,currency:string){ await db.createUser(name,currency); await get().loadAll() },
  async addAccount(a:any){ await db.insert('accounts',a); await get().loadAll() },
  async addTransaction(t:any){
    await db.insert('transactions',t)
    // update account balance
    const acc = get().accounts.find((x:any)=>x.id===t.account_id)
    if(acc){ const delta = t.type==='income'? t.amount : -t.amount; await db.update('accounts', acc.id, { balance: (acc.balance||0)+delta }) }
    await get().loadAll()
  },
  async deleteTransaction(id:number){ await db.remove('transactions',id); await get().loadAll() },
  async addDebt(d:any){ await db.insert('debts',d); await get().loadAll() },
  async addDebtPayment(p:any){
    await db.insert('debt_payments',p)
    const debt = get().debts.find((x:any)=>x.id===p.debt_id)
    const paid = get().debtPayments.filter((x:any)=>x.debt_id===p.debt_id).reduce((s:number,x:any)=>s+x.amount,0)+p.amount
    const total = debt.principal * (1 + (debt.interest_rate||0)/100)
    const status = paid >= total ? 'paid' : paid>0 ? 'partial' : 'active'
    await db.update('debts', debt.id, { status })
    await get().loadAll()
  },
  async setBudget(b:any){ await db.insert('budgets',b); await get().loadAll() },
  async updateUser(patch:any){ await db.updateUser(patch); await get().loadAll() },
  async backup(){
    const data = { user:get().user, accounts:get().accounts, categories:get().categories, transactions:get().transactions, budgets:get().budgets, debts:get().debts, debtPayments:get().debtPayments }
    return JSON.stringify(data,null,2)
  },
  async restore(json:string){
    const data = JSON.parse(json)
    localStorage.setItem('ft_db', JSON.stringify(data))
    await get().loadAll()
  }
}))
