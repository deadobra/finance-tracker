import { db } from '../db/sqlite'

export async function checkRecurring(){
  const txns = await db.list('transactions')
  const recurs = txns.filter((t:any)=>t.is_recurring)
  const today = new Date().toISOString().slice(0,10)
  for(const r of recurs){
    const last = new Date(r.date)
    let next = new Date(last)
    const rule = r.recurrence_rule
    if(rule==='daily') next.setDate(next.getDate()+1)
    if(rule==='weekly') next.setDate(next.getDate()+7)
    if(rule==='monthly') next.setMonth(next.getMonth()+1)
    if(rule==='yearly') next.setFullYear(next.getFullYear()+1)
    if(next.toISOString().slice(0,10) <= today){
      await db.insert('transactions',{...r, id: undefined, date: today, is_recurring:0, recurrence_rule:null, created_at: new Date().toISOString()})
    }
  }
}
