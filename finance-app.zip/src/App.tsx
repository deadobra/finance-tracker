import { useEffect, useState } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import BottomNav from './components/BottomNav'
import Onboarding from './pages/Onboarding'
import Dashboard from './pages/Dashboard'
import Transactions from './pages/Transactions'
import Debts from './pages/Debts'
import Accounts from './pages/Accounts'
import Settings from './pages/Settings'
import AddTransaction from './pages/AddTransaction'
import DebtDetail from './pages/DebtDetail'
import { initDB } from './db/init'
import { useAppStore } from './store/useAppStore'
import { checkRecurring } from './utils/recurring'

export default function App() {
  const [ready, setReady] = useState(false)
  const { user, loadAll, theme } = useAppStore()

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
  }, [theme])

  useEffect(() => {
    (async () => {
      await initDB()
      await loadAll()
      await checkRecurring()
      setReady(true)
    })()
  }, [])

  if (!ready) return <div className="h-screen grid place-items-center text-slate-500">Loading...</div>
  if (!user) return <Onboarding />

  return (
    <div className="max-w-[430px] mx-auto min-h-screen flex flex-col pb-20 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/transactions" element={<Transactions />} />
        <Route path="/transactions/new" element={<AddTransaction />} />
        <Route path="/debts" element={<Debts />} />
        <Route path="/debts/:id" element={<DebtDetail />} />
        <Route path="/accounts" element={<Accounts />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      <BottomNav />
    </div>
  )
}
