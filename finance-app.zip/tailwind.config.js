/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html','./src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        income: '#22c55e',
        expense: '#ef4444',
        owe: '#f97316',
        owed: '#3b82f6',
        primary: '#6366f1'
      }
    }
  },
  plugins: []
}
